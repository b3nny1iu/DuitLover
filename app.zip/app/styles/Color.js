export const Color = {
    'primary'   : '#4E9F3D',
    'secondary' : '#1E5128',
    'dark'      : '#191A19',
    'light'     : '#D8E9A8',
    'white'     : '#FFFFFF',
    'light_gray': '#c5c5c5',
}